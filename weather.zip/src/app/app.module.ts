import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { WeatherComponent } from './weather/weather.component';
import { ForecastComponent } from './forecast/forecast.component';
import { AppRoutingModule } from './app-routing.module';
import { WeatherService } from './services/weather.service';
import { DateConverterPipe } from './pipes/date-converter.pipe';

@NgModule({
  imports:      [ BrowserModule, FormsModule , HttpClientModule , AppRoutingModule,ReactiveFormsModule],
  declarations: [ AppComponent, WeatherComponent, ForecastComponent, DateConverterPipe ],
  providers:[WeatherService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
