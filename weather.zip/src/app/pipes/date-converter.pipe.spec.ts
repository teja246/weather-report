import { DateConverterPipe } from './date-converter.pipe';

describe('DateConverterPipe', () => {
  it('create an instance', () => {
    const pipe = new DateConverterPipe();
    expect(pipe).toBeTruthy();
  });
});
