import { Component, OnInit } from '@angular/core';
import { WeatherService } from './../services/weather.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-weather',
  templateUrl: './weather.component.html',
  styleUrls: ['./weather.component.css']
})
export class WeatherComponent implements OnInit {

  constructor(private ws: WeatherService) { }

  ngOnInit() {
    this.weatherDataArray = JSON.parse(localStorage.getItem('weatherDataSource'));
  }
  isSpinner = false;
  weatherData = { zipcode: '', data: '', forecastLink: '', icon: "" };
  weatherDataArray = [];
  weatherForm = new FormGroup({
    zipcode: new FormControl('', [
      Validators.required
    ])
  });
  getzipcode() {
    return this.weatherForm.get('zipcode').value
  }
  onSubmit() {
    this.isSpinner = true;
    this.getWeatherData(this.getzipcode());
    this.weatherForm.reset();
  }
  getWeatherData(zipcode) {
    this.ws.addWeatherData(zipcode).subscribe(
      result => {
        this.isSpinner = false;
        this.weatherData.data = result;
        this.weatherData.zipcode = zipcode;
        this.weatherData.forecastLink = this.weatherData.forecastLink =
          'forecast/' + this.weatherData.zipcode;
        if (this.weatherData.data != null && this.weatherData.data != '') {
          this.weatherData.forecastLink =
            'forecast/' + this.weatherData.zipcode;
          console.log(this.weatherData)
          this.weatherDataArray = this.weatherDataArray || [];
          this.weatherDataArray.push(
            JSON.parse(JSON.stringify(this.weatherData))
          );
          alert('Data Inserted Successfully')
          localStorage.setItem(
            'weatherDataSource',
            JSON.stringify(this.weatherDataArray)
          );
        } else {
          alert('Data not found try with other zipcode');
        }
      },
      error => {
        console.log('error', error);
        this.isSpinner = true;
        alert('Data  not found try with other zipcode');
      }
    );

  }
  findById(zipcode: any) {
    let index = this.weatherDataArray.findIndex(obj => obj.zipcode == zipcode);
    return index;
  }
  findAverage(min, max) {
    let avg: any = (min + max) / 2;
    avg = avg.toFixed(2);
    return avg;
  }
  clearWeatherData() {
    this.weatherData.data = '';
    this.weatherData.zipcode = '';
    this.weatherData.forecastLink = '';
  }
  deleteCity(index) {
    this.weatherDataArray.splice(index, 1);
    localStorage.setItem(
      'weatherDataSource',
      JSON.stringify(this.weatherDataArray)
    );
  }
}

