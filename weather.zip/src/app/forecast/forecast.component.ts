import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WeatherService } from './../services/weather.service';

@Component({
  selector: 'app-forecast',
  templateUrl: './forecast.component.html',
  styleUrls: ['./forecast.component.css']
})
export class ForecastComponent implements OnInit {

  constructor(private router: Router, private arouter: ActivatedRoute, private ws: WeatherService) { }
  pincode: string = '';
  forecastData = { "city": "", "cod": "", "message": 0, "cnt": 40, "list": [] }
  ngOnInit() {
    this.forecastData.list = []
    this.arouter.params.subscribe(params => {
      this.pincode = params['id'];
      if (this.pincode != '' && this.pincode != null) {
        this.addForecastData(this.pincode)
      }
    });
  }
 
  getWeatherCondition(condition) {
    if (condition == 'Clear'){
      return 'Sunny';
    } else if (condition == 'Rain') {
      return 'Rainy';
    } else if (condition == 'Clouds') {
      return 'Cloudy'
    }
  }
  goWeather() {
    this.router.navigateByUrl('');
  }
  dateConverter(m) {
    let d: any;
    for (let i = 0; i < this.list.length; i++) {
       d = new Date(m*1000);
       return d.toDateString()
    }
  }
  list = [];
  addForecastData(pincode) {
    this.ws.getForcastData(pincode).subscribe(
      result => {
        this.forecastData.list = [];
        this.forecastData = result;
        this.list = this.forecastData.list;
      },
      error => {
        console.log('error', error);
        alert('Data  not found try with other Pincode');
      }
    );
  }
}
