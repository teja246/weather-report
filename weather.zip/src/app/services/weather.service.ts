import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class WeatherService {


  private APIKey="5a4b2d457ecbef9eb2a71e480b947604";
  constructor(private httpClient: HttpClient) {}

  addWeatherData(pincode: any): Observable<any> {
    let url = 'http://api.openweathermap.org/data/2.5/forecast/daily?zip='+pincode+'&appid='+ this.APIKey;
    return this.httpClient.get(url);
  }
  getForcastData(pincode: any): Observable<any> {
    let url = 'http://api.openweathermap.org/data/2.5/forecast/daily?zip='+pincode+'&cnt=5&appid='+ this.APIKey
    return this.httpClient.get(url);
}
}
